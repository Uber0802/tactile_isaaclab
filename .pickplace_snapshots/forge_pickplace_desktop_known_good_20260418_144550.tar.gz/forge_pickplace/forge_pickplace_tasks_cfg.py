# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import isaaclab.sim as sim_utils
from isaaclab.assets import ArticulationCfg
from isaaclab.utils import configclass

from isaaclab_tasks.direct.factory.factory_tasks_cfg import Hole8mm
from isaaclab_tasks.direct.forge.forge_tasks_cfg import ForgePegInsert


@configclass
class ForgePegInsertPickPlace(ForgePegInsert):
    """Pick-and-place variant: peg starts inside a source hole; place it in the destination hole."""

    # Offset of source hole relative to destination hole (x, y, z), applied in world frame at reset.
    source_hole_offset: list = [0.0, 0.10, 0.0]

    # Gripper starts clearly above the peg top (peg sticks ~2.5 cm above the source hole),
    # leaving room for the fingers to descend and grasp.
    hand_init_pos: list = [0.0, 0.0, 0.10]
    hand_init_pos_noise: list = [0.02, 0.02, 0.01]
    hand_init_orn_noise: list = [0.0, 0.0, 0.2]

    # Franka finger joint width when the gripper is fully open (meters, each finger).
    gripper_open_width: float = 0.04

    # Insertion depth of the peg into the source hole at reset.
    # 0 places the peg base at the hole base (peg sticks out (peg_height - hole_height)).
    peg_source_insertion: float = 0.0

    # Approach reward: encourages the gripper fingertip to close in on the peg.
    # r_approach = exp(-dist / approach_scale), in [0, 1]. Smaller scale = sharper gradient.
    approach_reward_scale: float = 1.0
    approach_scale: float = 0.05

    # Lift reward: encourages raising the peg above the source-hole tip (clearance for pull-out).
    # r_lift is linear in [0, 1] as the peg base goes from the source-hole base to
    # (source-hole tip + lift_clear_margin). Saturates at 1 beyond the clear margin.
    lift_reward_scale: float = 1.0
    lift_clear_margin: float = 0.02

    source_fixed_asset: ArticulationCfg = ArticulationCfg(
        prim_path="/World/envs/env_.*/SourceFixedAsset",
        spawn=sim_utils.UsdFileCfg(
            usd_path=Hole8mm().usd_path,
            activate_contact_sensors=True,
            rigid_props=sim_utils.RigidBodyPropertiesCfg(
                disable_gravity=False,
                max_depenetration_velocity=5.0,
                linear_damping=0.0,
                angular_damping=0.0,
                max_linear_velocity=1000.0,
                max_angular_velocity=3666.0,
                enable_gyroscopic_forces=True,
                solver_position_iteration_count=192,
                solver_velocity_iteration_count=1,
                max_contact_impulse=1e32,
            ),
            mass_props=sim_utils.MassPropertiesCfg(mass=Hole8mm().mass),
            collision_props=sim_utils.CollisionPropertiesCfg(contact_offset=0.005, rest_offset=0.0),
        ),
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(0.6, 0.1, 0.05), rot=(1.0, 0.0, 0.0, 0.0), joint_pos={}, joint_vel={}
        ),
        actuators={},
    )
