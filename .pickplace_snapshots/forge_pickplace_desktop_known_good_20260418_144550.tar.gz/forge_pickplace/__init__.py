# Copyright (c) 2022-2026, The Isaac Lab Project Developers (https://github.com/isaac-sim/IsaacLab/blob/main/CONTRIBUTORS.md).
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import gymnasium as gym

from isaaclab_tasks.direct.forge import agents as forge_agents

##
# Register Gym environments.
##

gym.register(
    id="Isaac-Forge-PegInsert-PickPlace-Direct-v0",
    entry_point=f"{__name__}.forge_pickplace_env:ForgePegInsertPickPlaceEnv",
    disable_env_checker=True,
    kwargs={
        "env_cfg_entry_point": f"{__name__}.forge_pickplace_env_cfg:ForgeTaskPegInsertPickPlaceCfg",
        "rl_games_cfg_entry_point": f"{forge_agents.__name__}:rl_games_ppo_cfg.yaml",
    },
)
